MongoDB Toolkit

Requirements :
Replica Set with/without keyfile authentication

Unsupported  :
Sharded Cluster

Tested with mongodb 3.2 using keyfile
