#!/usr/bin/env python

#
# Copyright (c) 2014, 2015 by Delphix. All rights reserved.
#

import os
import sys
import json
import argparse
from argparse import RawTextHelpFormatter


SCRIPT_DESCRIPTION = """\
This script builds toolkit JSON files from specially structured
directories of the form:

<sourceDirectory>/
    <toolkitName>/
        main.json
        resources/
            <resources>
        virtual/
            [status.sh | status.ps1]
            [provision.lua]
            [start.lua]
            [stop.lua]
            [preSnapshot.lua]
            [postSnapshot.lua]
        staged/
            [status.sh | status.ps1]
            [resync.lua]
            [startStaging.lua]
            [stopStaging.lua]
            [preSnapshot.lua]
            [postSnapshot.lua]
        direct/
            [preSync.lua]
            [postSync.lua]

Notes:
A single toolkit cannot be both staged and direct, and so only one of the two
directories is required (whichever type matches the type in the main.json passed
in to build the toolkit)
The status script is optional.
All other directories and files must exist as expected.

This script will not check the syntax of your scripts so ensure these scripts
are functional before building a toolkit.
"""


def main():
    # parse args and print usage message if necessary
    parser = argparse.ArgumentParser(description=SCRIPT_DESCRIPTION, formatter_class=RawTextHelpFormatter)
    parser.add_argument("sourceDirectory", help="The directory containing the toolkit root directory.", type=str)
    parser.add_argument("toolkitName", help="The name of the toolkit to build. " +
            "This should match the name of the directory containing the source scripts.", type=str)
    parser.add_argument("outputFile", help="The file to which the toolkit contents will be written.", type=str)
    args = parser.parse_args()

    # save args to variables with shorter names
    srcdir = args.sourceDirectory
    toolkit = args.toolkitName
    outfile = args.outputFile
    print "Generating toolkit \"" + toolkit + "\"..."

    # read manifest into JSON object to start off
    print "Reading main.json"
    toolkit_dir = os.path.join(srcdir, toolkit)
    manifest = None
    with open(os.path.join(toolkit_dir, "main.json"), 'r') as f:
        try:
            manifest = json.loads(f.read())
        except:
            sys.stderr.write("ERROR: Encountered error parsing main.json. " +
                    "Check that the file is accessible and contains valid JSON.\n")
            raise

    # read resources
    read_resources(manifest, toolkit_dir)

    # read workflow scripts from relevant directories into manifest JSON
    print "Reading linked source definition"
    read_linked_source_definition(manifest, toolkit_dir)

    print "Reading virtual source definition"
    read_virtual_source_definition(manifest, toolkit_dir)

    # dump JSON into toolkit directory
    with open(outfile, 'w') as f:
        try:
            f.write(json.dumps(manifest, indent=4))
        except:
            sys.stderr.write("ERROR: Encountered error writing out toolkit JSON.\n")
            raise

    # exit with success
    print "SUCCESS - Generated toolkit \"" + outfile + "\""
    sys.exit(0)


def read_linked_source_definition(manifest, toolkit_dir):
    is_staged_toolkit = manifest["linkedSourceDefinition"]["type"] == "ToolkitLinkedStagedSource"
    is_direct_toolkit = manifest["linkedSourceDefinition"]["type"] == "ToolkitLinkedDirectSource"

    if not is_staged_toolkit and not is_direct_toolkit:
        print "A toolkit's linked source definition must be of type ToolkitLinkedStagedSource or ToolkitLinkedDirectSource"
        sys.exit(-1)

    # make sure appropriate directory exists (staged or linking)
    has_staged_dir = os.path.isdir(os.path.join(toolkit_dir, "staged"))
    has_direct_dir = os.path.isdir(os.path.join(toolkit_dir, "direct"))

    if has_staged_dir and has_direct_dir:
        print "A toolkit directory cannot contain both staged and direct directory. The direct must match the toolkit LinkedSourceDefinition type"
        sys.exit(-1)

    if is_staged_toolkit:
        if has_direct_dir:
            print "The toolkit LinkedSourceDefinition type ToolkitLinkedStagedSource requires a staged folder, not a direct folder"
            sys.exit(-1)
        manifest["linkedSourceDefinition"]["preSnapshot"] = read_script(toolkit_dir, "staged/preSnapshot.lua")
        manifest["linkedSourceDefinition"]["postSnapshot"] = read_script(toolkit_dir, "staged/postSnapshot.lua")
        manifest["linkedSourceDefinition"]["startStaging"] = read_script(toolkit_dir, "staged/startStaging.lua")
        manifest["linkedSourceDefinition"]["stopStaging"] = read_script(toolkit_dir, "staged/stopStaging.lua")
        manifest["linkedSourceDefinition"]["resync"] = read_script(toolkit_dir, "staged/resync.lua")

        # status script is optional
        status = read_status_script(toolkit_dir, "staged")
        if status is not None:
            manifest["linkedSourceDefinition"]["statusScript"] = status

    elif is_direct_toolkit:
        if has_staged_dir:
            print "The toolkit LinkedSourceDefinition type ToolkitLinkedDirectSource requires a direct folder, not a staged folder"
            sys.exit(-1)
        manifest["linkedSourceDefinition"]["preSync"] = read_script(toolkit_dir, "direct/preSync.lua")
        manifest["linkedSourceDefinition"]["postSync"] = read_script(toolkit_dir, "direct/postSync.lua")


def read_virtual_source_definition(manifest, toolkit_dir):
    manifest["virtualSourceDefinition"]["provision"] = read_script(toolkit_dir, "virtual/provision.lua")
    manifest["virtualSourceDefinition"]["start"] = read_script(toolkit_dir, "virtual/start.lua")
    manifest["virtualSourceDefinition"]["stop"] = read_script(toolkit_dir, "virtual/stop.lua")
    manifest["virtualSourceDefinition"]["preSnapshot"] = read_script(toolkit_dir, "virtual/preSnapshot.lua")
    manifest["virtualSourceDefinition"]["postSnapshot"] = read_script(toolkit_dir, "virtual/postSnapshot.lua")

    # For initialize hook script is optional, only add to manifest if script exists
    if os.path.exists(os.path.join(toolkit_dir, "virtual/initialize.lua")):
        initScripts = read_script(toolkit_dir, "virtual/initialize.lua")
        manifest["virtualSourceDefinition"]["initialize"] = initScripts

    # status script is optional
    status = read_status_script(toolkit_dir, "virtual")
    if status is not None:
        manifest["virtualSourceDefinition"]["statusScript"] = status


def read_status_script(toolkit_dir, source_type):
    for filename in ["status.sh", "status.ps1"]:
        relpath = os.path.join(source_type, filename)
        filepath = os.path.join(toolkit_dir, relpath)
        if (os.path.isfile(filepath)):
            try:
                with open(filepath) as f:
                    script = f.read()
                    print "  %s added" % relpath
                    return script;
            except IOError:
                print "  Can't read " + filename
                sys.stderr.write("Could not open " + filename + "; adding no status script...\n")
                return None
    print "  status does not exist, adding no script"
    return None


def read_script(toolkit_dir, script):
    path = os.path.join(toolkit_dir, script)
    if os.path.exists(path):
        print "  %s added" % script
        with open(path) as f:
            return f.read()
    else:
        print "  %s does not exist, adding no-op script" % script
        return ""


def read_resources(manifest, toolkit_dir):
    print "Reading resources ..."
    assert "resources" not in manifest, manifest
    manifest["resources"] = {}

    # iterate through resources directory
    rdir = os.path.join(toolkit_dir, "resources")
    for dirpath, dirnames, filenames in os.walk(rdir):
        for filename in filenames:
            abspath = os.path.join(dirpath, filename)
            rname = os.path.relpath(abspath, start=rdir)
            print "  resources/%s" % rname
            with open(abspath) as f:
                manifest["resources"][rname] = f.read()


if __name__ == "__main__":
    main()
