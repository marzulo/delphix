nohup /bin/shutdown.sh
