# edit setenv.sh with provision parameters
sed ${DLPX_DATA_DIRECTORY}/bin/setenv.sh > setenv.sh.tmp \
    -e 's|^CATALINA_HOME=.*$|CATALINA_HOME='"${DLPX_DATA_DIRECTORY}"'|' \
    -e 's|^JAVA_HOME=.*$|JAVA_HOME='"${WEBAPP_JAVA_HOME}"'|'
mv setenv.sh.tmp ${DLPX_DATA_DIRECTORY}/bin/setenv.sh
