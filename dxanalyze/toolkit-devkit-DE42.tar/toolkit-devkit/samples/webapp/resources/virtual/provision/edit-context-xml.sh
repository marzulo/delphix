# edit context.xml with provision parameters
CONTEXT_XML_PATH=${DLPX_DATA_DIRECTORY}/webapps/ROOT/META-INF/context.xml
sed ${CONTEXT_XML_PATH} > context.xml.tmp \
    -e 's|url="jdbc:oracle:thin:@.*"|url=\"jdbc:oracle:thin:@'"${WEBAPP_DB_HOSTNAME}:1521:${WEBAPP_DB_SID}"'\"|' \
    -e 's|\(username=\"\)\(.*\)\(\" password.*\)|\1'"${WEBAPP_DB_USER}"'\3|' \
    -e 's|\(.* password=\"\)\(.*\)\(\" maxActive.*\)|\1'"${WEBAPP_DB_PASSWORD}"'\3|'
mv context.xml.tmp ${CONTEXT_XML_PATH}
