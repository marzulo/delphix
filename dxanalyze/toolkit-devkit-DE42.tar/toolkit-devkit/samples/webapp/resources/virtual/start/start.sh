nohup /bin/startup.sh
