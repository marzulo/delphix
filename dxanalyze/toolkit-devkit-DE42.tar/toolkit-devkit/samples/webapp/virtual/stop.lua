RunCommand {
    command = resources["virtual/stop/stop.sh"],
    environment = source.environment,
    host = source.host,
    environmentUser = source.environmentUser,
    env = {
        DLPX_DATA_DIRECTORY = source.dataDirectory
    }
}