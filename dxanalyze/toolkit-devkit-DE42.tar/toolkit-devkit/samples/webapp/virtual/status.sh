if pgrep -lf "^/bin/java -Djava.util.logging.config.file="; then
    exit 0
else
    exit 128
fi
