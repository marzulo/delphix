RunCommand {
    command = resources["virtual/start/start.sh"],
    environment = source.environment,
    host = source.host,
    environmentUser = source.environmentUser,
    env = {
        DLPX_DATA_DIRECTORY = source.dataDirectory
    }
}