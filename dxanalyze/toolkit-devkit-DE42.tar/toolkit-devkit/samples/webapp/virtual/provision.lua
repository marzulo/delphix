env = {
    DLPX_DATA_DIRECTORY = source.dataDirectory,
    WEBAPP_JAVA_HOME = source.javaHome,
    WEBAPP_DB_HOSTNAME = source.dbHostname,
    WEBAPP_DB_SID = source.dbSID,
    WEBAPP_DB_USER = source.dbUser,
    WEBAPP_DB_PASSWORD = source.dbPassword
}

RunCommand {
command = resources["virtual/provision/edit-setenv.sh"],
environment = source.environment,
host = source.host,
user = source.environmentUser,
variables = env
}

RunCommand {
command = resources["virtual/provision/edit-context-xml.sh"],
environment = source.environment,
host = source.host,
user = source.environmentUser,
variables = env
}